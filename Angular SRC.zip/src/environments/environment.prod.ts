export const environment = {
  production: true,
  apiURL: 'http://taskmanager-env.3fhmixbfjx.us-east-2.elasticbeanstalk.com/api/'
};
